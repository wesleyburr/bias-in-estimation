tsinterp
========

tsinterp: A Time Series Interpolation Package for R